from django.shortcuts import render
from .forms import InputForm
# Create your views here.
def home_view(request):
		context ={}
		context['form']= InputForm()
		return render(request, "home.html", context)
from django.shortcuts import render

# Create your views here.
def home_view(request):

	# logic of view will be implemented here
	return render(request, "home.html")