from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from .forms import InputForm

# Create your views here.
def home_view(request):
        context ={}
        context['form']= InputForm()
        return render(request, "home.html", context)
from django.shortcuts import render

# Create your views here.
def home_view(request):
	print(request.GET)
	return render(request, "home.html")
from django.shortcuts import render

# Create your views here.
def home_view(request):
	print(request.POST)
	return render(request, "home.html")
