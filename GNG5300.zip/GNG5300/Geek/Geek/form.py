from django import forms
class GeeksForm(forms.Form):
	title = forms.CharField()
	description = forms.CharField()
	views = forms.IntegerField()
	available = forms.BooleanField()
from django import forms

class GeeksForm(forms.Form):
	title = forms.CharField(widget = forms.Textarea)
	description = forms.CharField(widget = forms.CheckboxInput)
	views = forms.IntegerField(widget = forms.TextInput)
	available = forms.BooleanField(widget = forms.Textarea)
from django import forms

class GeeksForm(forms.Form):
	title = forms.CharField()
	description = forms.CharField()
	views = forms.IntegerField()
	date = forms.DateField()
from django import forms

class GeeksForm(forms.Form):
	title = forms.CharField()
	description = forms.CharField()
	views = forms.IntegerField()
	date = forms.DateField(widget = forms.SelectDateWidget)
from django import forms
from .models import GeeksModel


# creating a form
class GeeksForm(forms.ModelForm):

	# create meta class
	class Meta:
		# specify model to be used
		model = GeeksModel

		# specify fields to be used
		fields = [
			"title",
			"description",
		]
from django.http import HttpResponse

def my_view(request):
	if request.method == 'GET':
		# <view logic>
		return HttpResponse('result')
from django.http import HttpResponse
from django.views import View

class MyView(View):
	def get(self, request):
		# <view logic>
		return HttpResponse('result')
