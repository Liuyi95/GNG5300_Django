from django.urls import path
#now import the views.py file into this code
from . import views
urlpatterns=[
    path('',views.index)
    ]
from django.urls import path

# importing views from views..py
from .views import geeks_view

urlpatterns = [
	path('', home_view ),
]
