from django import forms
from .models import GeeksModel
# create a form
class GeeksForm(forms.Form):
        title = forms.CharField()
        description = forms.CharField()
x# import form class from django
from django import forms

# import GeeksModel from models.py

# create a ModelForm
class GeeksForm(forms.ModelForm):
	# specify the name of model to use
	class Meta:
		model = GeeksModel
		fields = "__all__"
from django import forms

# create a form
class GeeksForm(forms.Form):
	title = forms.CharField()
	description = forms.CharField()
