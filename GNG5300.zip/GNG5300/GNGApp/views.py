from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from django.shortcuts import render

# relative import of forms
from .forms import GeeksForm

# importing formset_factory
from django.forms import formset_factory


def formset_view(request):
    context = {}

    # creating a formset
    GeeksFormSet = formset_factory(GeeksForm)
    formset = GeeksFormSet()

    # Add the formset to context dictionary
    context['formset'] = formset
    return render(request, "home.html", context)


def index(request):
    return HttpResponse("Hello Geeks")


from django.shortcuts import render

# relative import of forms
from .forms import GeeksForm

# importing formset_factory
from django.forms import formset_factory


def formset_view(request):
    context = {}

    # creating a formset
    GeeksFormSet = formset_factory(GeeksForm)
    formset = GeeksFormSet()

    # Add the formset to context dictionary
    context['formset'] = formset
    return render(request, "home.html", context)


from django.shortcuts import render

# relative import of forms
from .forms import GeeksForm

# importing formset_factory
from django.forms import formset_factory


def formset_view(request):
    context = {}

    # creating a formset
    GeeksFormSet = modelformset_factory(GeeksForm)
    formset = GeeksFormSet()

    # Add the formset to context dictionary
    context['formset'] = formset
    return render(request, "home.html", context)


from django.shortcuts import render

# relative import of forms
from .models import GeeksModel

# importing formset_factory
from django.forms import modelformset_factory


def modelformset_view(request):
    context = {}

    # creating a formset and 5 instances of GeeksForm
    GeeksFormSet = modelformset_factory(GeeksModel, fields=['title', 'description'], extra=3)
    formset = GeeksFormSet()

    # Add the formset to context dictionary
    context['formset'] = formset
    return render(request, "home.html", context)
